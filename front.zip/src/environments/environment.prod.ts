export const environment = {
  production: true,

  /**
   * URL backend en producción
   * - Ajusta al dominio real
   */
  apiBaseUrl: 'http://localhost:3000',
};
