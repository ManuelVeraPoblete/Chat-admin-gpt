import { bootstrapApplication } from '@angular/platform-browser';
import { provideRouter } from '@angular/router';
import { provideAnimations } from '@angular/platform-browser/animations';
import { provideHttpClient, withInterceptors } from '@angular/common/http';

import { App } from './app/app';
import { routes } from './app/app.routes';
import { DB_DASHBOARD_PROVIDERS } from './app/features/db-dashboard/application/db-dashboard.facade';

// ✅ NUEVO
import { authBearerInterceptor } from './app/core/http/auth-bearer.interceptor';

bootstrapApplication(App, {
  providers: [
    provideRouter(routes),
    provideAnimations(),

    // ✅ HttpClient habilitado + interceptor JWT
    provideHttpClient(withInterceptors([authBearerInterceptor])),

    ...DB_DASHBOARD_PROVIDERS,
  ],
}).catch((err) => console.error(err));
