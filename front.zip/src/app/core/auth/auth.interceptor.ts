import { HttpErrorResponse, HttpEvent, HttpHandlerFn, HttpInterceptorFn, HttpRequest } from '@angular/common/http';
import { inject } from '@angular/core';
import { catchError, Observable, switchMap, throwError } from 'rxjs';
import { AuthService } from './auth.service';

/**
 * Interceptor producción:
 * - Agrega Authorization si hay accessToken en memoria
 * - En 401, intenta refresh 1 vez y reintenta request
 */
export const authInterceptor: HttpInterceptorFn = (
  req: HttpRequest<unknown>,
  next: HttpHandlerFn,
): Observable<HttpEvent<unknown>> => {
  const auth = inject(AuthService);

  const token = auth.token;
  const authReq = token
    ? req.clone({ setHeaders: { Authorization: `Bearer ${token}` }, withCredentials: true })
    : req.clone({ withCredentials: true });

  return next(authReq).pipe(
    catchError((err: HttpErrorResponse) => {
      if (err.status !== 401) return throwError(() => err);

      return auth.refresh().pipe(
        switchMap((newToken) => {
          if (!newToken) return throwError(() => err);

          const retryReq = req.clone({
            setHeaders: { Authorization: `Bearer ${newToken}` },
            withCredentials: true,
          });

          return next(retryReq);
        }),
      );
    }),
  );
};
