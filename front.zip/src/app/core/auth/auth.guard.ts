import { CanActivateFn, Router } from '@angular/router';
import { inject } from '@angular/core';
import { AuthService } from './auth.service';

/**
 * Guard simple:
 * - si no hay token en memoria => redirige a /login
 *
 * Nota:
 * - En producción, al cargar la app, un APP_INITIALIZER llamará refresh()
 *   para levantar sesión sin mostrar login si hay cookie válida.
 */
export const authGuard: CanActivateFn = () => {
  const auth = inject(AuthService);
  const router = inject(Router);

  if (auth.token) return true;

  router.navigateByUrl('/login');
  return false;
};
