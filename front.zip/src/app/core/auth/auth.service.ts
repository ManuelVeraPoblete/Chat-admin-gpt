import { Inject, Injectable } from '@angular/core';
import { HttpClient } from '@angular/common/http';
import { BehaviorSubject, catchError, map, Observable, of, tap, throwError } from 'rxjs';

import { APP_CONFIG, AppConfig } from '../config/app-config';

/**
 * Tipos del usuario autenticado.
 */
export type AuthUser = {
  id: string;
  email: string;
  role: string;
};

type LoginResponse = {
  accessToken: string;
  user: AuthUser;
};

type RefreshResponse = {
  accessToken: string;
};

@Injectable({ providedIn: 'root' })
export class AuthService {
  /**
   * ✅ Producción:
   * - accessToken sólo en memoria (no localStorage)
   * - refresh token en cookie HttpOnly (lo gestiona backend)
   */
  private readonly accessToken$ = new BehaviorSubject<string | null>(null);
  private readonly user$ = new BehaviorSubject<AuthUser | null>(null);

  private readonly baseUrl: string;

  constructor(
    private readonly http: HttpClient,
    @Inject(APP_CONFIG) config: AppConfig,
  ) {
    this.baseUrl = config.apiBaseUrl;
  }

  /** Access token en memoria (runtime) */
  get token(): string | null {
    return this.accessToken$.value;
  }

  /** Usuario en memoria (runtime) */
  get user(): AuthUser | null {
    return this.user$.value;
  }

  /**
   * Login:
   * - backend debe setear cookie refresh HttpOnly (withCredentials)
   * - retorna accessToken + user
   */
  login(email: string, password: string): Observable<AuthUser> {
    return this.http
      .post<LoginResponse>(
        `${this.baseUrl}/auth/login`,
        { email, password },
        { withCredentials: true },
      )
      .pipe(
        tap((res) => {
          this.accessToken$.next(res.accessToken);
          this.user$.next(res.user);
        }),
        map((res) => res.user),
      );
  }

  /**
   * Refresh silencioso:
   * - backend lee cookie HttpOnly y entrega nuevo accessToken
   */
  refresh(): Observable<string | null> {
    return this.http
      .post<RefreshResponse>(
        `${this.baseUrl}/auth/refresh`,
        {},
        { withCredentials: true },
      )
      .pipe(
        tap((res) => this.accessToken$.next(res.accessToken)),
        map((res) => res.accessToken),
        catchError(() => {
          // si refresh falla => usuario no autenticado
          this.accessToken$.next(null);
          this.user$.next(null);
          return of(null);
        }),
      );
  }

  /**
   * Logout:
   * - backend borra cookie refresh
   * - frontend limpia token/usuario en memoria
   */
  logout(): Observable<void> {
    return this.http
      .post<void>(`${this.baseUrl}/auth/logout`, {}, { withCredentials: true })
      .pipe(
        tap(() => {
          this.accessToken$.next(null);
          this.user$.next(null);
        }),
        catchError((err) => {
          // aunque falle, limpiamos cliente para no quedar a medias
          this.accessToken$.next(null);
          this.user$.next(null);
          return throwError(() => err);
        }),
      );
  }
}
