import { InjectionToken } from '@angular/core';

/**
 * Configuración central de la app.
 * - Se inyecta en servicios (Auth, API, etc.)
 */
export interface AppConfig {
  /** Base URL del backend (ej: http://localhost:3000) */
  apiBaseUrl: string;

  /** Flags de debug */
  debug?: boolean;
}

/**
 * Token DI para configuración global.
 */
export const APP_CONFIG = new InjectionToken<AppConfig>('APP_CONFIG');
