import { Routes } from '@angular/router';
import { authGuard } from './core/auth/auth.guard';

export const routes: Routes = [
  {
    path: 'login',
    loadComponent: () =>
      import('./features/auth/presentation/pages/login/login.page').then(m => m.LoginPage),
  },
  {
    path: 'logs',
    canActivate: [authGuard],
    loadComponent: () =>
      import('./features/logs/presentation/pages/logs/logs.page').then(m => m.LogsPage),
  },
  { path: '', redirectTo: 'logs', pathMatch: 'full' },
{ path: '**', redirectTo: 'logs' },
];
