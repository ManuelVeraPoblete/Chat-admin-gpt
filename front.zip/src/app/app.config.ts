import { ApplicationConfig } from '@angular/core';
import { provideRouter } from '@angular/router';
import { provideHttpClient, withInterceptorsFromDi } from '@angular/common/http';

import { routes } from './app.routes';
import { APP_CONFIG_PROVIDER } from './core/config/app-config.provider';
import { AUTH_INITIALIZER_PROVIDER } from './core/auth/auth.initializer';

export const appConfig: ApplicationConfig = {
  providers: [
    provideRouter(routes),
    provideHttpClient(withInterceptorsFromDi()),

    // ✅ IMPORTANTE: Config primero
    APP_CONFIG_PROVIDER,

    // ✅ Si tienes initializer de auth
    AUTH_INITIALIZER_PROVIDER,
  ],
};
